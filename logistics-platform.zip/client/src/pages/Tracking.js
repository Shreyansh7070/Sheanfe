
import React from "react";

function Tracking() {
  return (
    <div>
      <h2>Live Shipment Tracking</h2>
      <iframe
        width="100%"
        height="500"
        src="https://www.marinetraffic.com/en/ais/embed/zoom:10"
        title="Tracking Map"
      ></iframe>
    </div>
  );
}

export default Tracking;
