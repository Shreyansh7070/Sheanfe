
import React from "react";

function UploadDocs() {
  return <h2>UploadDocs Page</h2>;
}

export default UploadDocs;
