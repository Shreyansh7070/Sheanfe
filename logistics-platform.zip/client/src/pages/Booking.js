
import React from "react";

function Booking() {
  return <h2>Booking Page</h2>;
}

export default Booking;
